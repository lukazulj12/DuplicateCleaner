# Duplicate Cleaner

Android aplikacija za pronalaženje, usporedbu i sigurno uklanjanje dupliciranih datoteka.
Radi isključivo lokalno na uređaju – bez interneta, registracije i oglasa.

> **Stanje provjere:** jezgra aplikacije (`core`: prepoznavanje duplikata, pravila odabira, prioritet mapa,
> vremenski filtar, sigurnost brisanja) kompajlirana je i testirana – vidi `TEST_RESULTS.md`.
> Android dio gradi se na GitHubu (poglavlje 1). Ako izgradnja javi pogrešku, pošaljite zapis pogreške.

## Sadržaj
1. Izgradnja APK-a na GitHubu (bez Android Studija)
2. Dvije inačice: `full` i `play`
3. Instalacija na mobitel
4. Kako se koristi (uključujući prioritet mapa, vremenski interval, rad u pozadini)
5. **Objava na Google Play – korak po korak**
6. Kako aplikacija prepoznaje duplikate
7. Dopuštenja
8. Arhitektura
9. Poznata ograničenja

---

## 1. Izgradnja APK-a na GitHubu

1. Na GitHubu otvorite svoj repozitorij → **Add file → Upload files** → povucite *sadržaj* raspakirane mape
   (ili sam zip – izgradnja ga sama raspakira) → **Commit changes**.
2. Datoteka `.github/workflows/build-apk.yml` pokreće izgradnju. Ako ste ranije napravili `main.yml`, zamijenite
   njegov sadržaj sadržajem `build-apk.yml` (ili ga obrišite), da se izgradnja ne pokreće dvaput.
3. Kartica **Actions** → zadnji prolaz → kad dobije zelenu kvačicu, dolje pod **Artifacts** preuzmite
   **DuplicateCleaner-apk** (unutra je `app-full-debug.apk`).

S Android Studijem (alternativa): *File → Open* → mapa projekta → *Build → Build APK(s)*; ili u terminalu
`./gradlew :app:assembleFullDebug`.

## 2. Dvije inačice iz istog koda

| | **full** (APK izravno na mobitel) | **play** (Google Play) |
|---|---|---|
| Fotografije, video, audio | ✅ | ✅ |
| Dokumenti/arhive u mapama koje dodate | ✅ | ✅ |
| „Pristup svim datotekama” (cijela pohrana) | ✅ neobavezno | ❌ (Google Play to dopuštenje odobrava samo upraviteljima datoteka, antivirusima i sl.) |
| Gumb i banner „Počasti developera kavom” (PayPal) | ✅ | ❌ isključeno – vidi 5.10 |

Inačica se bira imenom zadatka: `assembleFullDebug`, `assembleFullRelease`, `bundlePlayRelease`.
Postavke inačica nalaze se u `app/build.gradle.kts` (`productFlavors`).

## 3. Instalacija na mobitel

Kopirajte APK na mobitel, otvorite ga i dopustite „Instaliraj nepoznate aplikacije” kada Android to zatraži.
Potreban je **Android 11 ili noviji**, root nije potreban.

> Debug APK i APK s Google Playa potpisani su različitim ključevima – prije instalacije s Playa deinstalirajte ručno instaliranu inačicu.

## 4. Kako se koristi

1. **Glavni zaslon** → „Odobri pristup” (fotografije, video, audio). Za dokumente: „Upravljanje mapama” → dodajte mape
   (u inačici `full` možete uključiti i „Pristup svim datotekama”).
2. **Skeniraj datoteke** – napredak, pregledane datoteke, duplikati i procjena prostora prikazuju se uživo; skeniranje se može otkazati.
3. **Pregled duplikata** → grupe, statusi **ZADRŽATI** / **PREDLOŽENO ZA BRISANJE**, razlog, „Zadrži ovu datoteku”, usporedba s povećanjem.
4. **Pregled prije brisanja** → konačan popis i prostor → **Potvrdi brisanje** → izvještaj. **Oporavak**: ikona sata na glavnom zaslonu.

### Novo u ovoj verziji

**Prioritet mapa** (Postavke → Pravila odabira → „Prioritet mapa”)
- **Povlaštene mape (do 3, redom)** – kopija u njima se zadržava. 1. ima najveću prednost (npr. 1. `DCIM/Camera/`, 2. `Pictures/Screenshots/`, 3. WhatsApp Images).
- **Podređene mape (do 3, redom)** – iz njih se duplikati brišu prije nego iz ostalih. 1. je najpodređenija (npr. 1. `Download/`).
- Mapa obuhvaća i sve podmape. Mape koje nisu navedene nalaze se između povlaštenih i podređenih.
- Mapa se bira s popisa čestih mapa, s popisa mapa na mobitelu ili upisom putanje.
- Pravilo je dio popisa pravila i može se pomicati gore/dolje (zadano je prvo, tj. ima prednost pred datumom i veličinom) ili isključiti.
- WhatsApp na Androidu 11+ sprema slike u `Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/` – ta je putanja među ponuđenima.

**Vremenski interval** (Postavke → Skeniranje → „Vremenski interval nastanka”)
- **Sva vremena** (zadano): datum se ne gleda, skeniraju se datoteke iz svih razdoblja.
- **Samo odabrani interval**: odaberite datum **Od** i/ili **Do**; skeniraju se samo datoteke nastale u tom intervalu.
  Prebacivanjem natrag na „Sva vremena” upisani datumi ostaju sačuvani za sljedeći put.
- „Primijeni samo na dokumente” (zadano) ili „na sve vrste datoteka”.
- Datum nastanka = datum snimanja ako je poznat, inače datum posljednje izmjene. Android ne bilježi stvarni datum stvaranja
  dokumenata; datum kopiranja se namjerno ne koristi. Datoteke bez poznatog datuma ne prolaze aktivan filtar.
- Na glavnom zaslonu prikazuje se koliko je datoteka preskočeno zbog intervala.

**Rad u pozadini** (Postavke → „Rad u pozadini”)
- **Nastavi skeniranje u pozadini** (zadano uključeno): usluga s obaviješću i *wake lock* – skeniranje se ne prekida kad se zaslon ugasi
  ili prijeđete u drugu aplikaciju. Obavijest ima gumb za otkazivanje.
- **Drži zaslon upaljenim tijekom skeniranja**: rezervna opcija za mobitele koji agresivno štede bateriju (Xiaomi, Huawei, Samsung…);
  radi dok je aplikacija otvorena. Na takvim mobitelima pomaže i: Postavke sustava → Aplikacije → Duplicate Cleaner → Baterija → „Bez ograničenja”.

**Počasti developera kavom** (samo inačica `full`)
- Mali okrugli gumb ☕ na glavnom zaslonu (dolje desno) i stavka u Postavkama.
- Nakon završenog skeniranja na vrhu se pojavi mali banner; ne prekida ništa, ima **X** i sam nestaje nakon 12 sekundi.
- Poveznica: `https://paypal.me/lfzulj` – mijenja se u `app/build.gradle.kts` (`DONATE_URL`).

## 5. Objava na Google Play – korak po korak

### 5.1 Prije prve objave (jednom)
- **ID aplikacije** je `hr.zulj.duplicatecleaner` (`app/build.gradle.kts` → `applicationId`). Nakon prve objave **ne može se promijeniti**.
  Ako želite drugi, promijenite ga sada.
- **Naziv „Duplicate Cleaner”**: na Playu već postoje aplikacije sličnog naziva. Dopušteno je, ali razmislite o razlikovnom dodatku
  (npr. „Duplicate Cleaner – Safe”) radi lakšeg pronalaženja. Naziv u aplikaciji mijenja se u `tools/strings_source.py` (`app_name`)
  pa pokrenite `python3 tools/strings_source.py`.
- Novi osobni razvojni računi (otvoreni nakon studenog 2023.) prije produkcije moraju provesti **zatvoreno testiranje: najmanje 12 testera, 14 dana zaredom**.
  Provjerite u Play Consoleu (Nadzorna ploča) vrijedi li to za vaš račun.

### 5.2 Ključ za potpisivanje (upload key)
Google Play traži da AAB bude potpisan vašim ključem za upload (Google zatim aplikaciju potpisuje svojim ključem – *Play App Signing*).

1. Napravite ključ (treba Java; naredbu `keytool` imate ako je instaliran JDK ili Android Studio):
   ```
   keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
   ```
   Upisat ćete lozinku i podatke (ime, grad, država `HR`). **Datoteku `upload.jks` i lozinku sačuvajte na sigurnom** (npr. i u upravitelju lozinki).
   Nikad je ne stavljajte u repozitorij.
2. Pretvorite ključ u tekst (Windows PowerShell, u mapi s ključem):
   ```
   [Convert]::ToBase64String([IO.File]::ReadAllBytes("upload.jks")) | Set-Content upload.b64
   ```
3. Na GitHubu: repozitorij → **Settings → Secrets and variables → Actions → New repository secret**, dodajte četiri tajne:

   | Naziv | Vrijednost |
   |---|---|
   | `SIGNING_KEYSTORE_BASE64` | cijeli sadržaj datoteke `upload.b64` |
   | `SIGNING_STORE_PASSWORD` | lozinka ključa |
   | `SIGNING_KEY_ALIAS` | `upload` |
   | `SIGNING_KEY_PASSWORD` | lozinka ključa (ista, ako niste zadali drugu) |

4. Pokrenite izgradnju (Actions → „Izgradi APK” → **Run workflow**). Pod Artifacts sada je i **DuplicateCleaner-google-play-aab**
   (`app-play-release.aab`) – to je datoteka za Google Play.

Lokalno (Android Studio): umjesto tajni napravite `keystore.properties` u korijenu projekta (u `.gitignore` je):
```
storeFile=C:/putanja/upload.jks
storePassword=...
keyAlias=upload
keyPassword=...
```
i pokrenite `./gradlew :app:bundlePlayRelease`.

### 5.3 Pravila privatnosti (obavezno)
Aplikacija traži pristup fotografijama, pa Google traži javnu poveznicu na pravila privatnosti. Tekst je spreman u `PRIVACY_POLICY.md`.
Najjednostavnije: na GitHubu napravite **javni gist** (gist.github.com) ili javnu stranicu (npr. Google Sites) s tim tekstom i kopirajte njezinu poveznicu.

### 5.4 Izrada aplikacije u Play Consoleu
**Sve aplikacije → Izradi aplikaciju**: naziv *Duplicate Cleaner*, zadani jezik hrvatski (ili engleski), *Aplikacija*, *Besplatno*, prihvatite izjave.

### 5.5 Postavljanje aplikacije (Nadzorna ploča → „Postavite aplikaciju”)
| Odjeljak | Što upisati |
|---|---|
| Pravila o privatnosti | poveznica iz 5.3 |
| Pristup aplikaciji | „Sve funkcije su dostupne bez posebnog pristupa” |
| Oglasi | „Ne, aplikacija ne sadrži oglase” |
| Ocjena sadržaja | upitnik: kategorija *Uslužni program/alati*, na sve „Ne” |
| Ciljana publika | 18+ (ili 13+); nije namijenjena djeci |
| **Sigurnost podataka** | „Prikuplja li aplikacija ili dijeli korisničke podatke?” → **Ne**. Aplikacija nema dopuštenje za internet, ništa ne šalje s uređaja. |
| Vladine aplikacije / financijske značajke / zdravlje | Ne |
| Kategorija | *Alati* |

### 5.6 Glavni unos trgovine
- Tekstovi (kratki i puni opis, HR i EN): `store/listing.md`.
- Ikona 512×512: `store/icon-512.png`.
- Istaknuta grafika 1024×500: `store/feature-graphic-1024x500.png`.
- Snimke zaslona: najmanje 2 (preporuka 4–8) s mobitela – glavni zaslon, rezultati, grupa s oznakama ZADRŽATI/BRISANJE, postavke.
  Snimka: istovremeno tipka za uključivanje + stišavanje.

### 5.7 Deklaracija dopuštenja za fotografije i videozapise
Zbog dopuštenja `READ_MEDIA_IMAGES` / `READ_MEDIA_VIDEO` Play Console traži obrazac (**Sadržaj aplikacije → Dopuštenja za fotografije i videozapise**).
Prijedlog obrazloženja:
> *Duplicate Cleaner's core function is to scan the user's entire photo and video library on the device to find exact and visually identical
> duplicates and let the user delete them. This requires reading all photos and videos, which the Android photo picker cannot provide
> (the user would have to select every photo manually). All processing happens on the device; nothing is uploaded.*

Ako Google odbije, opcija je obrazloženje doraditi i ponovno poslati; aplikacija bez tog pristupa nema smisla.

### 5.8 Usluga u prvom planu
**Sadržaj aplikacije → Usluge u prvom planu**: vrsta *Data sync* – „Skeniranje i uspoređivanje datoteka koje je korisnik pokrenuo; napredak u obavijesti,
korisnik ga može otkazati.” Po potrebi priložite kratki video (snimka zaslona) pokretanja skeniranja.

### 5.9 Objava izdanja
1. **Testiranje → Interno testiranje** (najbrže, bez pregleda) ili **Zatvoreno testiranje** → *Izradi novo izdanje*.
2. Prihvatite **Play App Signing** (preporučeno).
3. Uploadajte `app-play-release.aab`, upišite bilješke o izdanju (npr. „Prvo izdanje”) → *Spremi* → *Pregledaj* → *Pokreni*.
4. Nakon testiranja: **Produkcija → Izradi novo izdanje** (ili „Promoviraj izdanje”) → države (npr. sve) → slanje na pregled (obično 1–7 dana).
5. **Svako sljedeće ažuriranje**: u `app/build.gradle.kts` povećajte `versionCode` (2, 3, …) i `versionName`, ponovno izgradite AAB i uploadajte.

### 5.10 Donacije i Google Play – važno
Pravila plaćanja Google Playa dopuštaju vanjsko plaćanje (npr. PayPal) samo za **donacije oslobođene poreza** (registrirane dobrotvorne udruge).
Donacija samom developeru preko PayPal poveznice može dovesti do **odbijanja ili uklanjanja aplikacije**. Zato je u inačici `play` gumb za donaciju
**isključen** (`SHOW_DONATE = false`), a u inačici `full` (APK izvan Playa) uključen.
- Ako svjesno prihvaćate rizik: u `app/build.gradle.kts`, u bloku `create("play")`, promijenite `SHOW_DONATE` u `"true"`.
- Siguran način na Playu: donacija preko Google Play naplate (jednokratna kupnja „Kava”) – može se dodati kasnije.

## 6. Kako aplikacija prepoznaje duplikate

| Razina | Metoda | Automatski prijedlog |
|---|---|---|
| **Potpuno identične** | SHA-256 cijelog sadržaja (najprije veličina i prvih 64 KB) | Da |
| **Ista fotografija** (WhatsApp kopija, smanjena, ponovno komprimirana) | pHash (≤ 6/64) + dHash + omjer stranica; EXIF orijentacija | Da |
| **Slične fotografije** | pHash unutar praga iz postavki (70–98 %) | **Nikad** – samo ručno |
| **Isti naziv, različit sadržaj** | isti naziv, različit SHA-256 | **Nikad** – samo informativno |

Pravila odabira datoteke koju zadržavate primjenjuju se redom: **prioritet mapa → datum → veličina → rezolucija** (redoslijed se mijenja u postavkama).
Ako na kraju ne ostane točno jedan pobjednik, ništa se ne označava i traži se ručna odluka.

Sigurnost: u svakoj grupi uvijek ostaje barem jedna datoteka; briše se isključivo potvrđeni popis; datoteka promijenjena nakon skeniranja se preskače;
datum kopiranja nikad se ne prikazuje kao datum snimanja.

## 7. Dopuštenja

| Dopuštenje | Svrha |
|---|---|
| `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO` (Android 13+), `READ_EXTERNAL_STORAGE` (11–12) | Čitanje medija radi usporedbe |
| `READ_MEDIA_VISUAL_USER_SELECTED` (14+) | Podrška za „Odabrane fotografije” (uz upozorenje o djelomičnom pristupu) |
| `ACCESS_MEDIA_LOCATION` | Izvorni bajtovi fotografija za točan SHA-256 (lokacija se ne čita ni ne sprema) |
| `MANAGE_EXTERNAL_STORAGE` | **Samo inačica `full`**, neobavezno – dokumenti i arhive na cijeloj pohrani |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK` | Skeniranje u pozadini, i kad je zaslon ugašen |
| `POST_NOTIFICATIONS` | Obavijest o napretku |

Mape dodane sistemskim biračem (Storage Access Framework) ne trebaju posebno dopuštenje. Dopuštenja `INTERNET` i `ACCESS_NETWORK_STATE`
izričito su uklonjena – aplikacija ne može ništa slati s uređaja.

## 8. Arhitektura

```
core/      čisti Kotlin (JVM testovi): modeli, SHA-256, pHash/dHash, grupiranje, pravila odabira (FolderPriority, KeepSelector),
           vremenski filtar, SelectionState (zaštita grupa), plan i izvršavanje brisanja, ScanEngine
app/       Android: MediaStore/SAF/datotečni sustav, ScanManager + ScanService (wake lock), DeletionManager (koš, oporavak),
           Room, DataStore, Jetpack Compose UI, HR/EN lokalizacija
  src/full/AndroidManifest.xml   dopuštenje "Pristup svim datotekama" (samo full)
store/     ikona, istaknuta grafika i tekstovi za Google Play
tools/     strings_source.py (izvor prijevoda), check_resources.py (provjera lokalizacije)
```

Kotlin 2.0.21, Compose (Material 3), Room 2.6.1, DataStore, Coroutines, Coil, AGP 8.10.1, Gradle 8.11.1, minSdk 30, **targetSdk 36** (zahtjev Google Playa od 31. 8. 2026.).

## 9. Poznata ograničenja

1. Android 11+ (minSdk 30).
2. Inačica `play` bez dodanih mapa vidi samo fotografije, videozapise i audiozapise; dokumente vidi samo u mapama dodanima kroz „Upravljanje mapama”.
   Sistemski birač ne dopušta korijen interne memorije, korijen mape Download ni Android/data.
3. Android/data, Android/obb i podaci drugih aplikacija nikad se ne skeniraju niti brišu.
4. Stvarni datum stvaranja dokumenata Android ne bilježi – vremenski interval koristi datum snimanja ili posljednje izmjene.
5. Oporavak: Androidov koš briše medije nakon ~30 dana; kopije iz dodanih mapa gube se deinstalacijom; uz „Pristup svim datotekama” datoteke se premještaju
   u mapu `DuplicateCleaner_Oporavak`.
6. Slične fotografije temelje se na perceptualnom hashu (ne na umjetnoj inteligenciji); video i audio uspoređuju se samo točno i po nazivu.
7. Neki proizvođači (Xiaomi, Huawei, Oppo…) i uz uslugu u prvom planu gase aplikacije u pozadini – tada uključite „Drži zaslon upaljenim” i/ili
   neograničenu potrošnju baterije za aplikaciju.
8. Android 15+: usluga u pozadini vrste *dataSync* ograničena je na 6 sati dnevno.
9. Brisanje medija uvijek prolazi kroz Androidov sistemski dijalog – zaštita sustava koja se ne može zaobići.
