# Pravila privatnosti – Duplicate Cleaner

*Vrijedi od: 28. 10. 2026.*

Duplicate Cleaner („aplikacija”) pronalazi i uklanja duplicirane datoteke na vašem uređaju.

**Podaci koje aplikacija prikuplja: nikakvi.**

- Aplikacija **nema pristup internetu** (ne traži dopuštenje INTERNET) i ne šalje nikakve podatke s uređaja.
- Fotografije, videozapisi, audiozapisi i dokumenti čitaju se **isključivo lokalno na uređaju** radi usporedbe (kontrolni zbroj SHA-256 i vizualni otisak fotografije).
- Rezultati skeniranja, postavke i predmemorija kontrolnih zbrojeva spremaju se samo u privatnu pohranu aplikacije na uređaju i brišu se deinstalacijom aplikacije.
- Nema registracije, oglasa, analitike ni alata trećih strana za praćenje.
- Datoteke se brišu **samo** nakon izričite potvrde korisnika.

**Dopuštenja:** pristup fotografijama, videozapisima i audiozapisima (radi pronalaženja duplikata), pristup lokaciji u medijima (samo radi točne usporedbe izvornih datoteka – lokacija se ne čita, ne prikazuje i ne sprema), obavijesti i rad u pozadini (prikaz napretka skeniranja).

**Kontakt:** lukafrane.zulj@gmail.com

---

# Privacy Policy – Duplicate Cleaner

*Effective: 28 October 2026.*

Duplicate Cleaner ("the app") finds and removes duplicate files on your device.

**Data collected by the app: none.**

- The app has **no internet access** (it does not request the INTERNET permission) and sends no data off the device.
- Photos, videos, audio and documents are read **only locally on the device** to compare them (SHA-256 checksum and a visual fingerprint of photos).
- Scan results, settings and the checksum cache are stored only in the app's private storage on the device and are removed when the app is uninstalled.
- No accounts, ads, analytics or third-party tracking.
- Files are deleted **only** after the user's explicit confirmation.

**Permissions:** access to photos, videos and audio (to find duplicates), media location access (only to compare original files accurately – location is never read, shown or stored), notifications and background work (scan progress).

**Contact:** lukafrane.zulj@gmail.com
