package hr.smartduplicatecleaner.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

private val Brand = Color(0xFF0E6B5C)

private val LightColors = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB8EFE0),
    onPrimaryContainer = Color(0xFF00201A),
    secondary = Color(0xFF4A635D),
    background = Color(0xFFF6F8F7),
    surface = Color(0xFFF6F8F7)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8DD5C2),
    onPrimary = Color(0xFF00382E),
    primaryContainer = Color(0xFF005144),
    onPrimaryContainer = Color(0xFFB8EFE0),
    background = Color(0xFF101413),
    surface = Color(0xFF101413)
)

/**
 * Semantičke boje statusa. Oznake "ZADRŽATI" i "ZA BRISANJE" razlikuju se bojom, ikonom
 * i tekstom – razlika je jasna i osobama koje ne razlikuju zelenu i crvenu.
 */
@Immutable
data class StatusColors(
    val keep: Color, val onKeep: Color, val keepContainer: Color,
    val delete: Color, val onDelete: Color, val deleteContainer: Color,
    val pending: Color, val pendingContainer: Color
)

private val LightStatus = StatusColors(
    keep = Color(0xFF1B6E2E), onKeep = Color.White, keepContainer = Color(0xFFD3F1D8),
    delete = Color(0xFFB3261E), onDelete = Color.White, deleteContainer = Color(0xFFFADAD6),
    pending = Color(0xFF7A5900), pendingContainer = Color(0xFFFFE9B0)
)

private val DarkStatus = StatusColors(
    keep = Color(0xFF7FD991), onKeep = Color(0xFF00390F), keepContainer = Color(0xFF16401F),
    delete = Color(0xFFFFB4AB), onDelete = Color(0xFF690005), deleteContainer = Color(0xFF5C1712),
    pending = Color(0xFFF2C14E), pendingContainer = Color(0xFF4A3800)
)

val LocalStatusColors = staticCompositionLocalOf { LightStatus }

@Composable
fun SdcTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    // Namjerno bez dinamičkih boja – prepoznatljiv izgled i predvidljiv kontrast statusnih oznaka.
    val colors = if (dark) DarkColors else LightColors
    androidx.compose.runtime.CompositionLocalProvider(LocalStatusColors provides if (dark) DarkStatus else LightStatus) {
        MaterialTheme(colorScheme = colors, content = content)
    }
}
