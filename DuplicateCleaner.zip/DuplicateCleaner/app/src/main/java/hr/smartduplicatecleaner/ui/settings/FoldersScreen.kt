package hr.smartduplicatecleaner.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.data.settings.AppSettings
import hr.smartduplicatecleaner.data.settings.ScanScope
import hr.smartduplicatecleaner.data.settings.SettingsRepository
import hr.smartduplicatecleaner.storage.StorageAccess
import hr.smartduplicatecleaner.storage.listMediaFolders
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.SectionTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Odabir mapa: cijela dostupna pohrana ili samo odabrane mape.
 * Medijske mape dolaze iz MediaStorea; ostale (npr. Download s dokumentima) dodaju se preko
 * sistemskog birača mapa (Storage Access Framework) i ostaju odobrene i nakon ponovnog pokretanja.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(repo: SettingsRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val settings by repo.settings.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()
    var folders by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(Unit) { folders = withContext(Dispatchers.IO) { listMediaFolders(context) } }

    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            try {
                context.contentResolver.takePersistableUriPermission(uri, flags)
            } catch (e: SecurityException) {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            scope.launch { repo.update { it.copy(safTrees = it.safTrees + uri.toString()) } }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.folder_selection)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } }
            )
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            item {
                SectionTitle(stringResource(R.string.scan_scope))
                RadioRow(settings.scope == ScanScope.WHOLE_STORAGE, stringResource(R.string.scope_whole)) {
                    scope.launch { repo.update { it.copy(scope = ScanScope.WHOLE_STORAGE) } }
                }
                RadioRow(settings.scope == ScanScope.SELECTED_FOLDERS, stringResource(R.string.scope_selected)) {
                    scope.launch { repo.update { it.copy(scope = ScanScope.SELECTED_FOLDERS) } }
                }
                if (!StorageAccess.hasAllFilesAccess()) {
                    NoticeCard(stringResource(R.string.saf_explanation), Modifier.padding(vertical = 8.dp), warning = false)
                }
            }

            item { SectionTitle(stringResource(R.string.saf_folders)) }
            items(settings.safTrees.toList(), key = { it }) { tree ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Folder, null)
                    Spacer(Modifier.size(8.dp))
                    Text(StorageAccess.treeDisplayName(tree), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    IconButton(onClick = {
                        try {
                            context.contentResolver.releasePersistableUriPermission(
                                Uri.parse(tree), Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            )
                        } catch (e: SecurityException) { /* već opozvano */ }
                        scope.launch { repo.update { it.copy(safTrees = it.safTrees - tree) } }
                    }) { Icon(Icons.Filled.Close, stringResource(R.string.remove)) }
                }
            }
            item {
                Button(onClick = { treeLauncher.launch(null) }, modifier = Modifier.padding(vertical = 8.dp)) {
                    Icon(Icons.Filled.CreateNewFolder, null)
                    Spacer(Modifier.size(6.dp))
                    Text(stringResource(R.string.add_folder))
                }
                Text(stringResource(R.string.saf_limits), style = MaterialTheme.typography.bodySmall)
            }

            item {
                SectionTitle(stringResource(R.string.media_folders))
                Text(
                    stringResource(if (settings.scope == ScanScope.SELECTED_FOLDERS) R.string.media_folders_hint else R.string.media_folders_disabled),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            val list = folders
            if (list == null) {
                item { CircularProgressIndicator(Modifier.padding(16.dp)) }
            } else if (list.isEmpty()) {
                item { Text(stringResource(R.string.no_media_folders), Modifier.padding(vertical = 8.dp)) }
            } else {
                items(list, key = { "m:$it" }) { dir ->
                    val depth = dir.trim('/').count { it == '/' }
                    Row(Modifier.padding(start = (depth * 20).dp)) {
                        CheckRow(
                            checked = dir in settings.selectedMediaDirs,
                            text = dir
                        ) { checked ->
                            scope.launch {
                                repo.update {
                                    it.copy(
                                        scope = ScanScope.SELECTED_FOLDERS,
                                        selectedMediaDirs = if (checked) it.selectedMediaDirs + dir else it.selectedMediaDirs - dir
                                    )
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.size(24.dp)) }
        }
    }
}
