package hr.smartduplicatecleaner.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.format.Formatters
import hr.smartduplicatecleaner.core.format.SizeUnit
import hr.smartduplicatecleaner.core.logic.FailureReason
import hr.smartduplicatecleaner.core.logic.Reason
import hr.smartduplicatecleaner.core.logic.ReasonCode
import hr.smartduplicatecleaner.core.model.CriterionType
import hr.smartduplicatecleaner.core.model.DateSource
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.scan.SourceWarning
import hr.smartduplicatecleaner.core.scan.WarningKind
import java.util.Locale

/** Prijevodi šifri iz jezgre u tekst na odabranom jeziku. */

@Composable
@ReadOnlyComposable
fun currentLocale(): Locale = LocalConfiguration.current.locales[0] ?: Locale.getDefault()

/** Formatiranje veličine i datuma prema postavkama korisnika. */
data class DisplayPrefs(val sizeUnit: SizeUnit = SizeUnit.AUTO, val europeanDates: Boolean = true)

@Composable
@ReadOnlyComposable
fun formatSize(bytes: Long, prefs: DisplayPrefs): String = Formatters.size(bytes, prefs.sizeUnit, currentLocale())

@Composable
@ReadOnlyComposable
fun formatDateTime(millis: Long, prefs: DisplayPrefs): String = Formatters.dateTime(millis, prefs.europeanDates, currentLocale())

@Composable
@ReadOnlyComposable
fun dateSourceLabel(source: String?): String = when (source) {
    DateSource.EXIF.name -> stringResource(R.string.date_src_exif)
    DateSource.MEDIA_METADATA.name -> stringResource(R.string.date_src_metadata)
    DateSource.DATE_ADDED.name -> stringResource(R.string.date_src_added)
    DateSource.LAST_MODIFIED.name -> stringResource(R.string.date_src_modified)
    else -> stringResource(R.string.date_src_unknown)
}

@Composable
@ReadOnlyComposable
fun criterionLabel(name: String?): String = when (name) {
    CriterionType.DATE.name -> stringResource(R.string.criterion_date)
    CriterionType.SIZE.name -> stringResource(R.string.criterion_size)
    CriterionType.RESOLUTION.name -> stringResource(R.string.criterion_resolution)
    CriterionType.FOLDERS.name -> stringResource(R.string.criterion_folders)
    else -> name.orEmpty()
}

@Composable
@ReadOnlyComposable
fun reasonText(r: Reason): String = when (r.code) {
    ReasonCode.KEEP_OLDER -> stringResource(R.string.reason_keep_older, dateSourceLabel(r.arg))
    ReasonCode.KEEP_NEWER -> stringResource(R.string.reason_keep_newer, dateSourceLabel(r.arg))
    ReasonCode.KEEP_LARGER -> stringResource(R.string.reason_keep_larger)
    ReasonCode.KEEP_SMALLER -> stringResource(R.string.reason_keep_smaller)
    ReasonCode.KEEP_HIGHER_RES -> stringResource(R.string.reason_keep_higher_res)
    ReasonCode.KEEP_FOLDER_PRIORITY -> {
        val folder = r.arg
        if (folder != null) stringResource(R.string.reason_keep_folder, folder) else stringResource(R.string.reason_keep_folder_other)
    }
    ReasonCode.DEL_NEWER -> stringResource(R.string.reason_del_newer, dateSourceLabel(r.arg))
    ReasonCode.DEL_OLDER -> stringResource(R.string.reason_del_older, dateSourceLabel(r.arg))
    ReasonCode.DEL_SMALLER -> stringResource(R.string.reason_del_smaller)
    ReasonCode.DEL_LARGER -> stringResource(R.string.reason_del_larger)
    ReasonCode.DEL_LOWER_RES -> stringResource(R.string.reason_del_lower_res)
    ReasonCode.DEL_FOLDER_PRIORITY -> stringResource(R.string.reason_del_folder, r.arg ?: "/")
    ReasonCode.DATE_FALLBACK_USED -> stringResource(R.string.reason_date_fallback, dateSourceLabel(r.arg))
    ReasonCode.SKIPPED_MISSING_DATA -> stringResource(R.string.reason_skipped_missing, criterionLabel(r.arg))
    ReasonCode.NO_CLEAR_WINNER -> stringResource(R.string.reason_no_clear_winner)
    ReasonCode.DIFFERENT_CONTENT -> stringResource(R.string.reason_different_content)
    ReasonCode.SIMILAR_ONLY -> stringResource(R.string.reason_similar_only)
    ReasonCode.NO_RULES -> stringResource(R.string.reason_no_rules)
    ReasonCode.MANUAL_CHOICE -> stringResource(R.string.reason_manual)
}

@Composable
@ReadOnlyComposable
fun groupTypeLabel(type: GroupType): String = when (type) {
    GroupType.EXACT -> stringResource(R.string.group_exact)
    GroupType.VISUAL -> stringResource(R.string.group_visual)
    GroupType.SIMILAR -> stringResource(R.string.group_similar)
    GroupType.SAME_NAME -> stringResource(R.string.group_same_name)
}

@Composable
@ReadOnlyComposable
fun groupTypeDescription(type: GroupType): String = when (type) {
    GroupType.EXACT -> stringResource(R.string.group_exact_desc)
    GroupType.VISUAL -> stringResource(R.string.group_visual_desc)
    GroupType.SIMILAR -> stringResource(R.string.group_similar_desc)
    GroupType.SAME_NAME -> stringResource(R.string.group_same_name_desc)
}

@Composable
@ReadOnlyComposable
fun categoryLabel(c: FileCategory): String = when (c) {
    FileCategory.IMAGE -> stringResource(R.string.cat_images)
    FileCategory.VIDEO -> stringResource(R.string.cat_videos)
    FileCategory.AUDIO -> stringResource(R.string.cat_audio)
    FileCategory.DOCUMENT -> stringResource(R.string.cat_documents)
    FileCategory.ARCHIVE -> stringResource(R.string.cat_archives)
    FileCategory.OTHER -> stringResource(R.string.cat_other)
}

@Composable
@ReadOnlyComposable
fun failureLabel(r: FailureReason): String = when (r) {
    FailureReason.NOT_FOUND -> stringResource(R.string.fail_not_found)
    FailureReason.PERMISSION_DENIED -> stringResource(R.string.fail_permission)
    FailureReason.USER_DECLINED -> stringResource(R.string.fail_declined)
    FailureReason.IO_ERROR -> stringResource(R.string.fail_io)
    FailureReason.CHANGED_SINCE_SCAN -> stringResource(R.string.fail_changed)
    FailureReason.CANCELLED -> stringResource(R.string.fail_cancelled)
    FailureReason.UNKNOWN -> stringResource(R.string.fail_unknown)
}

@Composable
@ReadOnlyComposable
fun sourceLabel(id: String): String = when {
    id == "mediastore" -> stringResource(R.string.src_media)
    id == "mediastore:IMAGE" -> stringResource(R.string.cat_images)
    id == "mediastore:VIDEO" -> stringResource(R.string.cat_videos)
    id == "mediastore:AUDIO" -> stringResource(R.string.cat_audio)
    id.startsWith("mediastore:") -> stringResource(R.string.src_volume, id.removePrefix("mediastore:"))
    id == "filesystem" || id.startsWith("filesystem:") -> stringResource(R.string.src_all_files)
    id.startsWith("saf:") -> stringResource(R.string.src_folder, id.removePrefix("saf:"))
    else -> id
}

@Composable
@ReadOnlyComposable
fun warningText(w: SourceWarning): String = when (w.kind) {
    WarningKind.PERMISSION_DENIED -> stringResource(R.string.warn_permission, sourceLabel(w.sourceId))
    WarningKind.INACCESSIBLE -> stringResource(R.string.warn_inaccessible, sourceLabel(w.sourceId))
    WarningKind.PARTIAL_ACCESS ->
        if (w.detail == "media_location") stringResource(R.string.warn_media_location)
        else stringResource(R.string.warn_partial, sourceLabel(w.sourceId))
    WarningKind.UNREADABLE_FILES -> stringResource(R.string.warn_unreadable, w.detail ?: "?")
    WarningKind.UNDECODABLE_IMAGES -> stringResource(R.string.warn_undecodable, w.detail ?: "?")
    WarningKind.ERROR -> stringResource(R.string.warn_error, w.detail ?: "")
}
