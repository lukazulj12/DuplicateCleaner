package hr.smartduplicatecleaner.ui.settings

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import hr.smartduplicatecleaner.BuildConfig
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.ui.components.DonateButton
import hr.smartduplicatecleaner.core.format.Formatters
import hr.smartduplicatecleaner.core.format.SizeUnit
import hr.smartduplicatecleaner.core.model.CriterionType
import hr.smartduplicatecleaner.core.model.DateKind
import hr.smartduplicatecleaner.core.model.DatePreference
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.ScanSettings
import hr.smartduplicatecleaner.core.model.SizePreference
import hr.smartduplicatecleaner.data.settings.AppSettings
import hr.smartduplicatecleaner.data.settings.DeletionMode
import hr.smartduplicatecleaner.data.settings.ScanScope
import hr.smartduplicatecleaner.data.settings.SettingsRepository
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.SectionTitle
import hr.smartduplicatecleaner.ui.components.categoryLabel
import hr.smartduplicatecleaner.ui.components.criterionLabel
import hr.smartduplicatecleaner.ui.components.formatSize
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(repo: SettingsRepository, onBack: () -> Unit, onFolders: () -> Unit) {
    val settings by repo.settings.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()
    fun update(t: (AppSettings) -> AppSettings) { scope.launch { repo.update(t) } }
    fun updateScan(t: (ScanSettings) -> ScanSettings) = update { it.copy(scan = t(it.scan)) }
    fun updateRules(t: (KeepRules) -> KeepRules) = update { it.copy(rules = t(it.rules)) }
    val prefs = DisplayPrefs(settings.sizeUnit, settings.europeanDates)
    var showCustomSize by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
        ) {
            // ---- Jezik ----
            SectionTitle(stringResource(R.string.language))
            val currentTag = AppCompatDelegate.getApplicationLocales().toLanguageTags()
            listOf("" to R.string.language_system, "hr" to R.string.language_hr, "en" to R.string.language_en).forEach { (tag, label) ->
                RadioRow(
                    selected = if (tag.isEmpty()) currentTag.isEmpty() else currentTag.startsWith(tag),
                    text = stringResource(label)
                ) {
                    // Aktivnost se automatski ponovno stvara s novim jezikom; izbor se pamti i nakon ponovnog pokretanja.
                    AppCompatDelegate.setApplicationLocales(
                        if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag)
                    )
                }
            }

            // ---- Skeniranje ----
            SectionTitle(stringResource(R.string.section_scanning))
            Text(stringResource(R.string.max_file_size), style = MaterialTheme.typography.titleSmall)
            Text(
                settings.scan.maxFileSizeBytes?.let { formatSize(it, prefs) } ?: stringResource(R.string.no_limit),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SettingsRepository.SIZE_PRESETS_MB.forEach { mb ->
                    val bytes = mb * ScanSettings.MB
                    FilterChip(
                        selected = settings.scan.maxFileSizeBytes == bytes,
                        onClick = { updateScan { s -> s.copy(maxFileSizeBytes = bytes) } },
                        label = { Text("$mb MB") }
                    )
                }
                FilterChip(
                    selected = settings.scan.maxFileSizeBytes == null,
                    onClick = { updateScan { s -> s.copy(maxFileSizeBytes = null) } },
                    label = { Text(stringResource(R.string.no_limit)) }
                )
                FilterChip(selected = false, onClick = { showCustomSize = true }, label = { Text(stringResource(R.string.custom_value)) })
            }
            Text(stringResource(R.string.max_file_size_hint), style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.file_types), style = MaterialTheme.typography.titleSmall)
            FileCategory.entries.forEach { c ->
                CheckRow(checked = c in settings.scan.categories, text = categoryLabel(c)) { checked ->
                    updateScan { s -> s.copy(categories = if (checked) s.categories + c else s.categories - c) }
                }
            }
            SwitchRow(
                text = stringResource(R.string.scan_video_audio),
                checked = FileCategory.VIDEO in settings.scan.categories && FileCategory.AUDIO in settings.scan.categories
            ) { on ->
                val av = setOf(FileCategory.VIDEO, FileCategory.AUDIO)
                updateScan { s -> s.copy(categories = if (on) s.categories + av else s.categories - av) }
            }

            Spacer(Modifier.height(12.dp))
            SwitchRow(text = stringResource(R.string.find_similar), checked = settings.scan.findSimilarPhotos) { on ->
                updateScan { s -> s.copy(findSimilarPhotos = on) }
            }
            var slider by remember(settings.scan.similarityPercent) { mutableFloatStateOf(settings.scan.similarityPercent.toFloat()) }
            Text(stringResource(R.string.similarity_threshold, slider.toInt()), style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = slider,
                onValueChange = { slider = it },
                onValueChangeFinished = { updateScan { s -> s.copy(similarityPercent = slider.toInt()) } },
                valueRange = 70f..98f,
                enabled = settings.scan.findSimilarPhotos
            )
            Text(stringResource(R.string.similarity_hint), style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(12.dp))
            DateRangeSection(
                from = settings.scan.dateFrom,
                to = settings.scan.dateTo,
                documentsOnly = settings.dateFilterDocumentsOnly,
                enabled = settings.dateFilterEnabled,
                prefs = prefs,
                onChange = { f, t -> updateScan { s -> s.copy(dateFrom = f, dateTo = t) } },
                onDocumentsOnly = { only -> update { it.copy(dateFilterDocumentsOnly = only) } },
                onEnabled = { on -> update { it.copy(dateFilterEnabled = on) } }
            )

            // ---- Rad u pozadini ----
            SectionTitle(stringResource(R.string.section_background))
            SwitchRow(stringResource(R.string.background_scan), settings.backgroundScan) { on -> update { it.copy(backgroundScan = on) } }
            Text(stringResource(R.string.background_scan_hint), style = MaterialTheme.typography.bodySmall)
            SwitchRow(stringResource(R.string.keep_screen_on), settings.keepScreenOn) { on -> update { it.copy(keepScreenOn = on) } }
            Text(stringResource(R.string.keep_screen_on_hint), style = MaterialTheme.typography.bodySmall)

            // ---- Mape ----
            SectionTitle(stringResource(R.string.folders))
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onFolders).padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.folder_selection), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        if (settings.scope == ScanScope.WHOLE_STORAGE) stringResource(R.string.scope_whole)
                        else stringResource(R.string.scope_selected_count, settings.selectedMediaDirs.size + settings.safTrees.size),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
            }

            // ---- Pravila odabira ----
            SectionTitle(stringResource(R.string.keep_rules_title))
            Text(stringResource(R.string.keep_rules_hint), style = MaterialTheme.typography.bodySmall)
            val order = settings.rules.normalizedOrder()
            order.forEachIndexed { index, criterion ->
                CriterionCard(
                    index = index,
                    total = order.size,
                    criterion = criterion,
                    rules = settings.rules,
                    onMove = { delta ->
                        val list = order.toMutableList()
                        val target = (index + delta).coerceIn(0, list.size - 1)
                        list.add(target, list.removeAt(index))
                        updateRules { r -> r.copy(order = list) }
                    },
                    onChange = { r -> updateRules { r } }
                )
            }

            // ---- Brisanje ----
            SectionTitle(stringResource(R.string.deletion_mode))
            RadioRow(settings.deletionMode == DeletionMode.RECOVERABLE, stringResource(R.string.mode_recoverable)) {
                update { it.copy(deletionMode = DeletionMode.RECOVERABLE) }
            }
            RadioRow(settings.deletionMode == DeletionMode.PERMANENT, stringResource(R.string.mode_permanent)) {
                update { it.copy(deletionMode = DeletionMode.PERMANENT) }
            }
            Text(stringResource(R.string.recovery_limits), style = MaterialTheme.typography.bodySmall)

            // ---- Prikaz ----
            SectionTitle(stringResource(R.string.section_display))
            SwitchRow(stringResource(R.string.european_dates), settings.europeanDates) { on -> update { it.copy(europeanDates = on) } }
            Text(stringResource(R.string.size_unit), style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SizeUnit.entries.forEach { u ->
                    FilterChip(
                        selected = settings.sizeUnit == u,
                        onClick = { update { it.copy(sizeUnit = u) } },
                        label = { Text(if (u == SizeUnit.AUTO) stringResource(R.string.size_auto) else u.name) }
                    )
                }
            }

            if (BuildConfig.SHOW_DONATE) {
                SectionTitle(stringResource(R.string.support_title))
                DonateButton(Modifier.fillMaxWidth())
            }

            Spacer(Modifier.height(24.dp))
            OutlinedButton(onClick = { showReset = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.reset_defaults)) }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (showCustomSize) {
        var text by remember { mutableStateOf("") }
        val parsed = Formatters.parseMegabytes(text)
        AlertDialog(
            onDismissRequest = { showCustomSize = false },
            title = { Text(stringResource(R.string.custom_size_title)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("MB") },
                    singleLine = true,
                    isError = text.isNotEmpty() && parsed == null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            },
            confirmButton = {
                TextButton(enabled = parsed != null, onClick = {
                    parsed?.let { b -> updateScan { s -> s.copy(maxFileSizeBytes = b) } }
                    showCustomSize = false
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { showCustomSize = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text(stringResource(R.string.reset_defaults)) },
            text = { Text(stringResource(R.string.reset_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    showReset = false
                    scope.launch { repo.resetToDefaults() }
                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.getEmptyLocaleList())
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CriterionCard(
    index: Int,
    total: Int,
    criterion: CriterionType,
    rules: KeepRules,
    onMove: (Int) -> Unit,
    onChange: (KeepRules) -> Unit
) {
    val enabled = rules.isEnabled(criterion)
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.priority_n, index + 1) + " · " + criterionLabel(criterion.name),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { onMove(-1) }, enabled = index > 0) { Icon(Icons.Filled.KeyboardArrowUp, stringResource(R.string.move_up)) }
                IconButton(onClick = { onMove(1) }, enabled = index < total - 1) { Icon(Icons.Filled.KeyboardArrowDown, stringResource(R.string.move_down)) }
            }
            when (criterion) {
                CriterionType.DATE -> {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            DatePreference.OLDER to R.string.keep_older,
                            DatePreference.NEWER to R.string.keep_newer,
                            DatePreference.NONE to R.string.date_no_preference
                        ).forEach { (p, l) ->
                            FilterChip(selected = rules.datePreference == p, onClick = { onChange(rules.copy(datePreference = p)) }, label = { Text(stringResource(l)) })
                        }
                    }
                    if (rules.datePreference != DatePreference.NONE) {
                        Text(stringResource(R.string.date_kind), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                        listOf(
                            DateKind.CAPTURE_WITH_FALLBACK to R.string.date_kind_capture_fallback,
                            DateKind.CAPTURE_ONLY to R.string.date_kind_capture_only,
                            DateKind.DATE_ADDED to R.string.date_kind_added,
                            DateKind.LAST_MODIFIED to R.string.date_kind_modified
                        ).forEach { (k, l) ->
                            RadioRow(rules.dateKind == k, stringResource(l)) { onChange(rules.copy(dateKind = k)) }
                        }
                    }
                }
                CriterionType.SIZE -> {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            SizePreference.LARGER to R.string.keep_larger,
                            SizePreference.SMALLER to R.string.keep_smaller,
                            SizePreference.NONE to R.string.size_no_preference
                        ).forEach { (p, l) ->
                            FilterChip(selected = rules.sizePreference == p, onClick = { onChange(rules.copy(sizePreference = p)) }, label = { Text(stringResource(l)) })
                        }
                    }
                    Text(stringResource(R.string.size_quality_warning), style = MaterialTheme.typography.bodySmall)
                }
                CriterionType.RESOLUTION -> SwitchRow(stringResource(R.string.prefer_higher_resolution), rules.preferHigherResolution) {
                    onChange(rules.copy(preferHigherResolution = it))
                }
                CriterionType.FOLDERS -> FolderPriorityEditor(rules, onChange)
            }
        }
    }
}

@Composable
fun RadioRow(selected: Boolean, text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun CheckRow(checked: Boolean, text: String, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
