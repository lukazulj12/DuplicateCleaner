# Rezultati testova

Datum izvođenja: 28. 10. 2026. Okruženje: Linux, OpenJDK 21, Kotlin 2.0.21 (kompajler ugrađen u Gradle 8.14.3), JUnit 4.13.2.

Što je stvarno izvršeno:

- **`core` modul** – kompajliran i testiran (43 testa, svi prolaze).
- **`app` modul** – test potpunosti lokalizacije (3 testa, prolaze) i skripta `tools/check_resources.py`.
- **Nije izvršeno:** izgradnja APK-a, kompajliranje Android koda i instrumentirani test promjene jezika
  (`LanguageSwitchTest`) – Android Gradle Plugin i Android SDK nisu se mogli preuzeti (poslužitelji
  dl.google.com, maven.google.com i repo1.maven.org blokirani su mrežnom politikom, HTTP 403).
  Na GitHubu ih pokreće workflow `build-apk.yml` (`:core:test :app:testFullDebugUnitTest :app:assembleFullDebug`).

## Scenariji iz specifikacije → testovi

| # | Scenarij | Test | Rezultat |
|---|---|---|---|
| 1 | Isti naziv, identičan sadržaj | `sameNameIdenticalContent_isExactGroup` | ✅ |
| 2 | Isti naziv, različit sadržaj | `sameNameDifferentContent_isSameNameGroupWithoutAutoSuggestion` | ✅ |
| 3 | Identične fotografije različitih naziva | `identicalPhotosDifferentNames_areFound`, `recompressedSmallerCopy_isVisualDuplicate_andOlderLargerIsKept` | ✅ |
| 4 | Fotografija kopirana u drugu mapu s novim datumom | `copiedPhotoWithNewFileDate_keepsOriginalByCaptureDate_orAsksUser` | ✅ |
| 5 | Fotografija s EXIF datumom i bez EXIF-a | `exifVersusNoExif_fallbackIsLabelled_andCaptureOnlySkips`, `exifDateParser_validatesValues` | ✅ |
| 6 | Različita veličina i rezolucija | `differentSizeAndResolution_rulesRespected`, `rulePriority_primarySecondaryTertiary`, `missingResolution_skipsCriterion_neverGuesses` | ✅ |
| 7 | Datoteke iznad ograničenja veličine | `filesAboveLimit_areExcludedAndReported` | ✅ |
| 8 | Nedostupna mapa / uskraćeno dopuštenje | `deniedSource_isReported_andOtherSourcesStillScanned`, `unreadableFile_isNeverReportedAsDuplicate` | ✅ |
| 9 | Ručna promjena automatskog odabira | `manualChangeOfAutomaticSelection` | ✅ |
| 10 | Pokušaj brisanja svih datoteka iz grupe | `cannotMarkAllFilesInGroup`, `crossGroupProtection_fileInTwoGroups`, `corruptedSavedState_withAllMarked_isSanitized` | ✅ |
| 11 | Otkazivanje skeniranja | `cancellation_stopsScan` | ✅ |
| 12 | Pogreška tijekom brisanja | `errorsDuringDeletion_areReported_andDoNotStopOthers`, `changedSinceScan_isNotDeleted` | ✅ |
| 13 | Promjena jezika i ponovno pokretanje | `LocalizationResourcesTest` (✅); `LanguageSwitchTest` (instrumentirani – nije izvršen, treba uređaj) | ✅ / ⏳ |
| 14 | Velika količina datoteka, nedostatak memorije | `manyFiles_andOutOfMemory_handledGracefully` (30 502 datoteke, OOM pri dekodiranju) | ✅ |
| — | Prioritet mapa: 3 povlaštene i 3 podređene mape, redoslijed, podmape | `scoring_orderAndSubfolders`, `preferredOrder_decidesKeeper_evenAgainstOlderDate`, `demotedOrder_deletesFromMostSubordinateFirst`, `folderRule_canBeMovedBelowDate_orDisabled` | ✅ |
| — | Vremenski interval nastanka (sve vrste / samo dokumenti) | `dateRange_onlyFilesCreatedInInterval_areScanned`, `dateRange_usesEarliestKnownDate_notCopyDate` | ✅ |
| — | Nikad se ne briše neoznačena/nepotvrđena datoteka | `runnerDeletesOnlyConfirmedFiles`, `undecidedGroups_neverAutoMarked`, `planRejectsUnknownFiles` | ✅ |

## Izlaz izvođenja

```
== core ==
  OK  ScanScenariosTest.samePhysicalFileFromTwoSources_isNotItsOwnDuplicate
  OK  ScanScenariosTest.exifVersusNoExif_fallbackIsLabelled_andCaptureOnlySkips
  OK  ScanScenariosTest.recompressedSmallerCopy_isVisualDuplicate_andOlderLargerIsKept
  OK  ScanScenariosTest.sameNameIdenticalContent_isExactGroup
  OK  ScanScenariosTest.identicalPhotosDifferentNames_areFound
  OK  ScanScenariosTest.differentSizeAndResolution_rulesRespected
  OK  ScanScenariosTest.deniedSource_isReported_andOtherSourcesStillScanned
  OK  ScanScenariosTest.emptyFiles_areIgnored
  OK  ScanScenariosTest.unreadableFile_isNeverReportedAsDuplicate
  OK  ScanScenariosTest.categoryAndFolderFilters_applied
  OK  ScanScenariosTest.cancellation_stopsScan
  OK  ScanScenariosTest.filesAboveLimit_areExcludedAndReported
  OK  ScanScenariosTest.copiedPhotoWithNewFileDate_keepsOriginalByCaptureDate_orAsksUser
  OK  ScanScenariosTest.sameNameDifferentContent_isSameNameGroupWithoutAutoSuggestion
  OK  ScanScenariosTest.manyFiles_andOutOfMemory_handledGracefully
  OK  SelectionAndDeletionTest.undecidedGroups_neverAutoMarked
  OK  SelectionAndDeletionTest.runnerDeletesOnlyConfirmedFiles
  OK  SelectionAndDeletionTest.changedSinceScan_isNotDeleted
  OK  SelectionAndDeletionTest.manualChangeOfAutomaticSelection
  OK  SelectionAndDeletionTest.crossGroupProtection_fileInTwoGroups
  OK  SelectionAndDeletionTest.cannotMarkAllFilesInGroup
  OK  SelectionAndDeletionTest.errorsDuringDeletion_areReported_andDoNotStopOthers
  OK  SelectionAndDeletionTest.planRejectsUnknownFiles
  OK  SelectionAndDeletionTest.onlyConfirmed_ignoresVisualGroups
  OK  SelectionAndDeletionTest.corruptedSavedState_withAllMarked_isSanitized
  OK  HashAndRulesTest.missingResolution_skipsCriterion_neverGuesses
  OK  HashAndRulesTest.exifOrientation_makesRotatedCopiesMatch
  OK  HashAndRulesTest.reasonEncoding_roundTrip
  OK  HashAndRulesTest.similarGroup_isAdvisoryOnly
  OK  HashAndRulesTest.rulePriority_primarySecondaryTertiary
  OK  HashAndRulesTest.exifDateParser_validatesValues
  OK  HashAndRulesTest.similarityThreshold_mapping
  OK  HashAndRulesTest.classifier
  OK  HashAndRulesTest.newerPreference_andDisabledRules
  OK  HashAndRulesTest.formatters
  OK  HashAndRulesTest.sha256_knownVector
  OK  HashAndRulesTest.perceptualHash_robustToScaleAndRecompression_butSeparatesDifferentPhotos
  OK  FolderPriorityAndDateTest.dateRange_usesEarliestKnownDate_notCopyDate
  OK  FolderPriorityAndDateTest.preferredOrder_decidesKeeper_evenAgainstOlderDate
  OK  FolderPriorityAndDateTest.demotedOrder_deletesFromMostSubordinateFirst
  OK  FolderPriorityAndDateTest.folderRule_canBeMovedBelowDate_orDisabled
  OK  FolderPriorityAndDateTest.scoring_orderAndSubfolders
  OK  FolderPriorityAndDateTest.dateRange_onlyFilesCreatedInInterval_areScanned
Ukupno: 43, neuspjelo: 0, trajanje: 1283 ms
== app (lokalizacija) ==
  OK  LocalizationResourcesTest.formatArgumentsMatch
  OK  LocalizationResourcesTest.keyCroatianTermsPresent
  OK  LocalizationResourcesTest.everyStringIsTranslated
Ukupno: 3, neuspjelo: 0, trajanje: 187 ms
== provjera resursa ==
EN: 268  HR: 267  korišteno: 268  nekorišteno: []
OK – lokalizacija je potpuna i dosljedna.
```
