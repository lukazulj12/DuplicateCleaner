package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.hash.GrayImage
import hr.smartduplicatecleaner.core.logic.FileClassifier
import hr.smartduplicatecleaner.core.model.DateSource
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.core.scan.CancelToken
import hr.smartduplicatecleaner.core.scan.ContentAccess
import hr.smartduplicatecleaner.core.scan.FileSource
import hr.smartduplicatecleaner.core.scan.ImageAnalysis
import hr.smartduplicatecleaner.core.scan.ImageMetadata
import hr.smartduplicatecleaner.core.scan.SourceWarning
import java.io.ByteArrayInputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.cos
import kotlin.math.sin

/** Pomoćni objekti za testove – simuliraju datoteke, izvore i pristup sadržaju. */
object Fixtures {
    const val DAY = 24L * 3600 * 1000
    /** 15. 1. 2023. 10:00 UTC */
    const val JAN_2023 = 1_673_776_800_000L
    /** 10. 10. 2026. 10:00 UTC */
    const val OCT_2026 = 1_791_626_400_000L

    fun file(
        path: String,
        size: Long,
        modified: Long = JAN_2023,
        added: Long? = modified,
        taken: Long? = null,
        width: Int? = null,
        height: Int? = null,
        mime: String? = null,
        source: SourceType = SourceType.MEDIA_STORE
    ): ScannedFile {
        val name = path.substringAfterLast('/')
        val dir = path.substringBeforeLast('/', "") + "/"
        return ScannedFile(
            key = "external_primary/" + path.lowercase(),
            uri = "content://test/$path",
            source = source,
            name = name,
            volume = "external_primary",
            relativeDir = dir,
            sizeBytes = size,
            mimeType = mime,
            category = FileClassifier.classify(name, mime),
            dateTakenMillis = taken,
            dateTakenSource = if (taken != null) DateSource.EXIF else null,
            dateAddedMillis = added,
            dateModifiedMillis = modified,
            width = width,
            height = height
        )
    }

    /** Sintetička "fotografija": glatki uzorak + pravokutnici, određena sjemenom. */
    fun photo(seed: Int, w: Int = 400, h: Int = 300): GrayImage {
        val px = IntArray(w * h)
        val rnd = java.util.Random(seed.toLong())
        val fx = 2.0 + rnd.nextDouble() * 6
        val fy = 2.0 + rnd.nextDouble() * 6
        val ph = rnd.nextDouble() * 6.28
        val rects = List(6) { IntArray(5) { rnd.nextInt(1000) } }
        for (y in 0 until h) for (x in 0 until w) {
            val nx = x.toDouble() / w
            val ny = y.toDouble() / h
            var v = 128 + 55 * sin(nx * fx * 6.28 + ph) + 45 * cos(ny * fy * 6.28 - ph)
            for (r in rects) {
                val x0 = r[0] * w / 1000; val y0 = r[1] * h / 1000
                val x1 = x0 + r[2] * w / 3000; val y1 = y0 + r[3] * h / 3000
                if (x in x0..x1 && y in y0..y1) v += (r[4] % 120) - 60
            }
            px[y * w + x] = v.toInt().coerceIn(0, 255)
        }
        return GrayImage(w, h, px)
    }

    /** Simulacija ponovne kompresije (kvantizacija + blagi šum), kao kod WhatsApp kopije. */
    fun recompress(img: GrayImage, seed: Int = 7): GrayImage {
        val rnd = java.util.Random(seed.toLong())
        val out = IntArray(img.pixels.size) { i ->
            ((img.pixels[i] / 6) * 6 + rnd.nextInt(5) - 2).coerceIn(0, 255)
        }
        return GrayImage(img.width, img.height, out)
    }

    /** Lagana izmjena (pomak svjetline u dijelu slike) – "slična", ali ne ista fotografija. */
    fun edit(img: GrayImage): GrayImage {
        val out = img.pixels.copyOf()
        for (y in 0 until img.height / 2) for (x in 0 until img.width / 3) {
            val i = y * img.width + x
            out[i] = (out[i] + 70).coerceAtMost(255)
        }
        return GrayImage(img.width, img.height, out)
    }
}

class FakeSource(
    override val id: String,
    private val files: List<ScannedFile>,
    private val failWith: Exception? = null
) : FileSource {
    override fun enumerate(cancel: CancelToken, emit: (ScannedFile) -> Unit, warn: (SourceWarning) -> Unit) {
        failWith?.let { throw it }
        files.forEach { cancel.throwIfCancelled(); emit(it) }
    }
}

class FakeContent : ContentAccess {
    val bytes = HashMap<String, ByteArray>()
    val images = HashMap<String, GrayImage>()
    val exifDates = HashMap<String, Long>()
    val unreadable = HashSet<String>()
    val oomOn = HashSet<String>()
    val opens = AtomicInteger(0)
    var onOpen: () -> Unit = {}

    override fun open(file: ScannedFile): InputStream {
        opens.incrementAndGet()
        onOpen()
        if (file.key in unreadable) throw IOException("nedostupno")
        return ByteArrayInputStream(bytes[file.key] ?: ByteArray(file.sizeBytes.toInt()))
    }

    override fun analyzeImage(file: ScannedFile): ImageAnalysis? {
        if (file.key in oomOn) throw OutOfMemoryError("test")
        val img = images[file.key] ?: return null
        return ImageAnalysis(img, file.width ?: img.width, file.height ?: img.height)
    }

    override fun readMetadata(file: ScannedFile): ImageMetadata? =
        ImageMetadata(exifDates[file.key], null, null)
}
