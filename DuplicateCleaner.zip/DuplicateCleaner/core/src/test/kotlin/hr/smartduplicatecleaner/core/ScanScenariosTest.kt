package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.Fixtures.DAY
import hr.smartduplicatecleaner.core.Fixtures.JAN_2023
import hr.smartduplicatecleaner.core.Fixtures.OCT_2026
import hr.smartduplicatecleaner.core.Fixtures.file
import hr.smartduplicatecleaner.core.logic.ReasonCode
import hr.smartduplicatecleaner.core.logic.Suggestion
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.ScanSettings
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.scan.CancelToken
import hr.smartduplicatecleaner.core.scan.ScanCancelledException
import hr.smartduplicatecleaner.core.scan.ScanEngine
import hr.smartduplicatecleaner.core.scan.ScanResult
import hr.smartduplicatecleaner.core.scan.WarningKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.concurrent.atomic.AtomicBoolean

/** Scenariji iz specifikacije (točka 15) na razini cijelog postupka skeniranja. */
class ScanScenariosTest {

    private fun scan(
        files: List<ScannedFile>,
        content: FakeContent,
        settings: ScanSettings = ScanSettings(parallelism = 2),
        rules: KeepRules = KeepRules()
    ): ScanResult = ScanEngine(listOf(FakeSource("test", files)), content).run(settings, rules, CancelToken.NONE)

    private fun bytes(seed: Int, size: Int) = ByteArray(size) { ((it * 31 + seed * 7) % 251).toByte() }

    // Scenarij 1
    @Test
    fun sameNameIdenticalContent_isExactGroup() {
        val a = file("DCIM/Camera/IMG_20230115.jpg", 5000)
        val b = file("Pictures/Backup/IMG_20230115.jpg", 5000)
        val c = FakeContent().apply { bytes[a.key] = bytes(1, 5000); bytes[b.key] = bytes(1, 5000) }
        val r = scan(listOf(a, b), c)
        val g = r.groups.single()
        assertEquals(GroupType.EXACT, g.type)
        assertEquals(setOf(a.key, b.key), g.fileKeys.toSet())
        assertEquals(r.files[a.key]!!.sha256, r.files[b.key]!!.sha256)
    }

    // Scenarij 2
    @Test
    fun sameNameDifferentContent_isSameNameGroupWithoutAutoSuggestion() {
        val a = file("DCIM/Camera/IMG_1.jpg", 5000)
        val b = file("Download/IMG_1.jpg", 5000)
        val c = file("Pictures/IMG_1.jpg", 4000)
        val content = FakeContent().apply {
            bytes[a.key] = bytes(1, 5000); bytes[b.key] = bytes(2, 5000); bytes[c.key] = bytes(3, 4000)
        }
        val r = scan(listOf(a, b, c), content)
        val g = r.groups.single()
        assertEquals(GroupType.SAME_NAME, g.type)
        assertEquals(3, g.members.map { it.contentLabel }.toSet().size)
        val d = r.decisions.getValue(g.id)
        assertTrue(d.needsManual)
        assertTrue(d.suggestedDeleteKeys.isEmpty())
        assertTrue(d.members.all { m -> m.reasons.any { it.code == ReasonCode.DIFFERENT_CONTENT } })
    }

    // Scenarij 3
    @Test
    fun identicalPhotosDifferentNames_areFound() {
        val a = file("DCIM/Camera/IMG_20230115.jpg", 4800, width = 4000, height = 3000)
        val b = file("WhatsApp/Media/IMG-20230120-WA0003.jpg", 4800, width = 4000, height = 3000)
        val img = Fixtures.photo(11)
        val content = FakeContent().apply {
            bytes[a.key] = bytes(5, 4800); bytes[b.key] = bytes(5, 4800)
            images[a.key] = img; images[b.key] = img
        }
        val r = scan(listOf(a, b), content)
        val g = r.groups.single()
        assertEquals(GroupType.EXACT, g.type)
        assertEquals(FileCategory.IMAGE, g.category)
    }

    // Scenarij 3b – ista fotografija, ponovno komprimirana i smanjena (WhatsApp), drugi naziv
    @Test
    fun recompressedSmallerCopy_isVisualDuplicate_andOlderLargerIsKept() {
        val original = file("DCIM/Camera/IMG_20230115.jpg", 4_800_000, modified = JAN_2023, taken = JAN_2023, width = 4000, height = 3000)
        val whatsapp = file("WhatsApp/Media/IMG-20261010-WA0001 (1).jpg", 2_100_000, modified = OCT_2026, width = 1920, height = 1080 * 4 / 3)
        val img = Fixtures.photo(21, 800, 600)
        val content = FakeContent().apply {
            bytes[original.key] = bytes(1, 10); bytes[whatsapp.key] = bytes(2, 10)
            images[original.key] = img
            images[whatsapp.key] = Fixtures.recompress(img.resize(480, 360))
            exifDates[original.key] = JAN_2023
        }
        val r = scan(listOf(original, whatsapp), content)
        val g = r.groups.single { it.type == GroupType.VISUAL }
        val d = r.decisions.getValue(g.id)
        assertFalse(d.needsManual)
        assertEquals(setOf(whatsapp.key), d.suggestedDeleteKeys)
        val kept = d.members.single { it.suggestion == Suggestion.KEEP }
        assertEquals(original.key, kept.fileKey)
        assertTrue(kept.reasons.any { it.code == ReasonCode.KEEP_OLDER && it.arg == "EXIF" })
        // WhatsApp kopija nema EXIF → za nju je korišten zamjenski datum, i to je zabilježeno.
        val deleted = d.members.single { it.suggestion == Suggestion.DELETE }
        assertTrue(deleted.reasons.any { it.code == ReasonCode.DATE_FALLBACK_USED })
    }

    // Scenarij 4 – ista fotografija kopirana u drugu mapu s novim datumom datoteke
    @Test
    fun copiedPhotoWithNewFileDate_keepsOriginalByCaptureDate_orAsksUser() {
        val original = file("DCIM/Camera/IMG_A.jpg", 3000, modified = JAN_2023, added = JAN_2023, width = 100, height = 100)
        val copy = file("Pictures/Novi/IMG_A.jpg", 3000, modified = OCT_2026, added = OCT_2026, width = 100, height = 100)
        val content = FakeContent().apply {
            bytes[original.key] = bytes(9, 3000); bytes[copy.key] = bytes(9, 3000)
            exifDates[original.key] = JAN_2023; exifDates[copy.key] = JAN_2023
        }
        // Isti EXIF datum, ista veličina i rezolucija → nema jasnog pobjednika → ručna odluka.
        val r1 = scan(listOf(original, copy), content)
        val d1 = r1.decisions.values.single()
        assertTrue(d1.needsManual)
        assertTrue(d1.suggestedDeleteKeys.isEmpty())
        // Uz pravilo "datum dodavanja" zadržava se original, kopija se predlaže.
        val r2 = scan(listOf(original, copy), content, rules = KeepRules(dateKind = hr.smartduplicatecleaner.core.model.DateKind.DATE_ADDED))
        assertEquals(setOf(copy.key), r2.decisions.values.single().suggestedDeleteKeys)
        // Uz prednost mape kamere također se zadržava original.
        val r3 = scan(listOf(original, copy), content, rules = KeepRules(preferredFolders = listOf("DCIM/Camera/")))
        assertEquals(setOf(copy.key), r3.decisions.values.single().suggestedDeleteKeys)
    }

    // Scenarij 5 – fotografija s EXIF datumom i fotografija bez EXIF podataka
    @Test
    fun exifVersusNoExif_fallbackIsLabelled_andCaptureOnlySkips() {
        // Kopija bez EXIF-a ima stariji datum izmjene od EXIF datuma originala (npr. pogrešan sat).
        val withExif = file("DCIM/Camera/a.jpg", 2000, modified = OCT_2026, width = 10, height = 10)
        val noExif = file("Download/a_copy.jpg", 2000, modified = JAN_2023 - 30 * DAY, width = 10, height = 10)
        val content = FakeContent().apply {
            bytes[withExif.key] = bytes(4, 2000); bytes[noExif.key] = bytes(4, 2000)
            exifDates[withExif.key] = JAN_2023
        }
        // CAPTURE_ONLY: jednoj datoteci nedostaje datum snimanja → datumski kriterij se preskače.
        val strict = scan(listOf(withExif, noExif), content, rules = KeepRules(dateKind = hr.smartduplicatecleaner.core.model.DateKind.CAPTURE_ONLY))
        val ds = strict.decisions.values.single()
        assertTrue(ds.notes.any { it.code == ReasonCode.SKIPPED_MISSING_DATA && it.arg == "DATE" })
        assertTrue(ds.suggestedDeleteKeys.isEmpty())
        // Sa zamjenom: zamjenski datum je jasno označen na datoteci bez EXIF-a.
        val loose = scan(listOf(withExif, noExif), content)
        val dl = loose.decisions.values.single()
        val m = dl.members.single { it.fileKey == noExif.key }
        assertTrue(m.reasons.any { it.code == ReasonCode.DATE_FALLBACK_USED && it.arg == "LAST_MODIFIED" })
        val w = dl.members.single { it.fileKey == withExif.key }
        assertFalse(w.reasons.any { it.code == ReasonCode.DATE_FALLBACK_USED })
    }

    // Scenarij 6 – različita veličina i rezolucija; pravila veličine i rezolucije
    @Test
    fun differentSizeAndResolution_rulesRespected() {
        val big = file("DCIM/Camera/big.jpg", 4_800_000, width = 4000, height = 3000)
        val small = file("Pictures/small.jpg", 2_100_000, width = 2000, height = 1500)
        val img = Fixtures.photo(33, 800, 600)
        val content = FakeContent().apply {
            bytes[big.key] = bytes(1, 5); bytes[small.key] = bytes(2, 5)
            images[big.key] = img; images[small.key] = Fixtures.recompress(img.resize(400, 300))
            exifDates[big.key] = JAN_2023; exifDates[small.key] = JAN_2023
        }
        val larger = scan(listOf(big, small), content)
        assertEquals(setOf(small.key), larger.decisions.values.single().suggestedDeleteKeys)
        val smaller = scan(
            listOf(big, small), content,
            rules = KeepRules(sizePreference = hr.smartduplicatecleaner.core.model.SizePreference.SMALLER, preferHigherResolution = false)
        )
        assertEquals(setOf(big.key), smaller.decisions.values.single().suggestedDeleteKeys)
        // Samo rezolucija (veličina isključena) → zadržava se veća rezolucija.
        val resOnly = scan(
            listOf(big, small), content,
            rules = KeepRules(sizePreference = hr.smartduplicatecleaner.core.model.SizePreference.NONE)
        )
        val d = resOnly.decisions.values.single()
        assertEquals(setOf(small.key), d.suggestedDeleteKeys)
        assertTrue(d.members.single { it.fileKey == big.key }.reasons.any { it.code == ReasonCode.KEEP_HIGHER_RES })
    }

    // Scenarij 7 – datoteke iznad ograničenja veličine
    @Test
    fun filesAboveLimit_areExcludedAndReported() {
        val mb = 1_000_000L
        val a = file("Movies/v1.mp4", 20 * mb)
        val b = file("Backup/v1.mp4", 20 * mb)
        val c = file("Download/doc.pdf", 2 * mb)
        val d = file("Documents/doc.pdf", 2 * mb)
        val content = FakeContent() // nul-bajtovi iste veličine = identičan sadržaj
        val r = scan(listOf(a, b, c, d), content, ScanSettings(maxFileSizeBytes = 10 * mb))
        assertEquals(1, r.groups.size)
        assertEquals(setOf(c.key, d.key), r.groups.single().fileKeys.toSet())
        assertEquals(2, r.stats.skippedBySize)
        assertEquals(2, r.stats.skippedPotentialDuplicates)
        assertEquals(40 * mb, r.stats.skippedBySizeBytes)
        // Bez ograničenja oba para se analiziraju.
        val all = scan(listOf(a, b, c, d), content, ScanSettings(maxFileSizeBytes = null))
        assertEquals(2, all.groups.size)
    }

    // Scenarij 8 – uskraćeno dopuštenje / nedostupna mapa
    @Test
    fun deniedSource_isReported_andOtherSourcesStillScanned() {
        val a = file("Download/x.pdf", 100)
        val b = file("Documents/x.pdf", 100)
        val engine = ScanEngine(
            listOf(
                FakeSource("mediastore", emptyList(), SecurityException("READ_MEDIA_IMAGES")),
                FakeSource("saf:tree", emptyList(), IllegalStateException("SD kartica izvađena")),
                FakeSource("files", listOf(a, b))
            ),
            FakeContent()
        )
        val r = engine.run(ScanSettings(), KeepRules(), CancelToken.NONE)
        assertEquals(1, r.groups.size)
        assertTrue(r.warnings.any { it.sourceId == "mediastore" && it.kind == WarningKind.PERMISSION_DENIED })
        assertTrue(r.warnings.any { it.sourceId == "saf:tree" && it.kind == WarningKind.INACCESSIBLE })
    }

    @Test
    fun unreadableFile_isNeverReportedAsDuplicate() {
        val a = file("Download/a.bin", 100)
        val b = file("Download/b.bin", 100)
        val content = FakeContent().apply { unreadable += b.key }
        val r = scan(listOf(a, b), content)
        assertTrue(r.groups.isEmpty())
        assertEquals(1, r.stats.unreadableFiles)
        assertTrue(r.warnings.any { it.kind == WarningKind.UNREADABLE_FILES })
    }

    @Test
    fun samePhysicalFileFromTwoSources_isNotItsOwnDuplicate() {
        val viaMedia = file("DCIM/Camera/a.jpg", 100)
        val viaSaf = viaMedia.copy(uri = "content://saf/a.jpg", source = hr.smartduplicatecleaner.core.model.SourceType.SAF_TREE)
        val engine = ScanEngine(listOf(FakeSource("m", listOf(viaMedia)), FakeSource("s", listOf(viaSaf))), FakeContent())
        val r = engine.run(ScanSettings(), KeepRules(), CancelToken.NONE)
        assertTrue(r.groups.isEmpty())
    }

    // Scenarij 11 – otkazivanje skeniranja
    @Test
    fun cancellation_stopsScan() {
        val files = (0 until 200).map { file("Download/f$it.bin", 1000) }
        val cancelled = AtomicBoolean(false)
        val content = FakeContent().apply { onOpen = { if (opens.get() > 20) cancelled.set(true) } }
        val engine = ScanEngine(listOf(FakeSource("s", files)), content)
        try {
            engine.run(ScanSettings(parallelism = 2), KeepRules(), { cancelled.get() })
            fail("Očekivano otkazivanje")
        } catch (e: ScanCancelledException) {
            // očekivano
        }
        assertTrue("Nakon otkazivanja ne smije se nastaviti čitanje", content.opens.get() < 60)
    }

    @Test
    fun emptyFiles_areIgnored() {
        val a = file("Download/e1.txt", 0)
        val b = file("Download/e2.txt", 0)
        val r = scan(listOf(a, b), FakeContent())
        assertTrue(r.groups.isEmpty())
        assertEquals(2, r.stats.emptyFiles)
    }

    @Test
    fun categoryAndFolderFilters_applied() {
        val a = file("Music/a.mp3", 50)
        val b = file("Music/b.mp3", 50)
        val c = file("Download/a.pdf", 60)
        val d = file("Documents/a.pdf", 60)
        val noAudio = scan(listOf(a, b, c, d), FakeContent(), ScanSettings(categories = setOf(FileCategory.DOCUMENT)))
        assertEquals(1, noAudio.groups.size)
        assertEquals(2, noAudio.stats.skippedByCategory)
        val onlyMusic = scan(listOf(a, b, c, d), FakeContent(), ScanSettings(includedRelativeDirs = setOf("Music")))
        assertEquals(setOf(a.key, b.key), onlyMusic.groups.single().fileKeys.toSet())
        assertEquals(2, onlyMusic.stats.skippedByFolder)
    }

    // Scenarij 14 – velika količina datoteka i nedostatak memorije
    @Test
    fun manyFiles_andOutOfMemory_handledGracefully() {
        val files = ArrayList<ScannedFile>()
        for (i in 0 until 30_000) files += file("Download/f$i.dat", 10_000L + i) // jedinstvene veličine – bez čitanja
        for (i in 0 until 500) files += file("Backup/dup$i.dat", 500L) // 500 identičnih (nul-bajtovi)
        val img = Fixtures.photo(3, 64, 48)
        val imgA = file("DCIM/p1.jpg", 777, width = 64, height = 48)
        val imgB = file("DCIM/p2.jpg", 778, width = 64, height = 48)
        val content = FakeContent().apply { images[imgA.key] = img; oomOn += imgB.key }
        files += imgA; files += imgB
        val start = System.nanoTime()
        val r = scan(files, content, ScanSettings(parallelism = 3))
        val ms = (System.nanoTime() - start) / 1_000_000
        val exact = r.groups.single { it.type == GroupType.EXACT }
        assertEquals(500, exact.members.size)
        assertEquals(1, r.stats.undecodableImages)
        assertTrue("Preveliko trajanje: $ms ms", ms < 20_000)
        // Sadržaj se čita samo za datoteke koje dijele veličinu (500), ne za svih 30 000.
        assertTrue(content.opens.get() <= 1000)
        assertNotNull(r.stats)
    }
}
