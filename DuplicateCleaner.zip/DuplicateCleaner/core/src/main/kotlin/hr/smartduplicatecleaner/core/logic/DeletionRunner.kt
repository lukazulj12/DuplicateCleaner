package hr.smartduplicatecleaner.core.logic

import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.scan.CancelToken

/** Rezultat brisanja pojedine datoteke. */
sealed class DeleteOutcome {
    /** Izbrisano ili premješteno u oporavak. [recoveryId] je oznaka zapisa za oporavak, ako postoji. */
    data class Done(val recoveryId: String? = null) : DeleteOutcome()
    data class Failed(val reason: FailureReason, val detail: String? = null) : DeleteOutcome()
}

enum class FailureReason { NOT_FOUND, PERMISSION_DENIED, USER_DECLINED, IO_ERROR, CHANGED_SINCE_SCAN, CANCELLED, UNKNOWN }

/** Apstrakcija brisanja – Android dio implementira MediaStore, SAF i izravno brisanje. */
fun interface FileDeleter {
    fun delete(file: ScannedFile): DeleteOutcome
}

data class DeletionReport(
    val succeeded: List<ScannedFile>,
    val failed: List<Pair<ScannedFile, DeleteOutcome.Failed>>,
    val recoverable: Boolean
) {
    val freedBytes: Long get() = succeeded.sumOf { it.sizeBytes }
}

object DeletionRunner {
    /**
     * Briše isključivo datoteke iz potvrđenog plana, jednu po jednu. Pogreška kod jedne datoteke
     * ne prekida ostale; svaka iznimka se bilježi u izvještaj.
     * Prije brisanja provjerava [stillValid] (npr. je li se datoteka promijenila od skeniranja).
     */
    fun run(
        plan: DeletionPlan,
        deleter: FileDeleter,
        recoverable: Boolean,
        cancel: CancelToken = CancelToken.NONE,
        stillValid: (ScannedFile) -> FailureReason? = { null },
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): DeletionReport {
        val ok = mutableListOf<ScannedFile>()
        val failed = mutableListOf<Pair<ScannedFile, DeleteOutcome.Failed>>()
        plan.items.forEachIndexed { index, file ->
            if (cancel.isCancelled()) {
                failed += file to DeleteOutcome.Failed(FailureReason.CANCELLED)
            } else {
                val invalid = try { stillValid(file) } catch (e: Exception) { FailureReason.UNKNOWN }
                if (invalid != null) {
                    failed += file to DeleteOutcome.Failed(invalid)
                } else {
                    when (val outcome = try { deleter.delete(file) } catch (e: SecurityException) {
                        DeleteOutcome.Failed(FailureReason.PERMISSION_DENIED, e.message)
                    } catch (e: Exception) {
                        DeleteOutcome.Failed(FailureReason.IO_ERROR, e.message)
                    }) {
                        is DeleteOutcome.Done -> ok += file
                        is DeleteOutcome.Failed -> failed += file to outcome
                    }
                }
            }
            onProgress(index + 1, plan.items.size)
        }
        return DeletionReport(ok, failed, recoverable)
    }
}
