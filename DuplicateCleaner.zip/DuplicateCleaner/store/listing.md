# Tekstovi za Google Play (kopirajte u Play Console → Glavni unos trgovine)

## Hrvatski (hr)
**Naziv (max 30):** Duplicate Cleaner

**Kratki opis (max 80):** Pronađi i sigurno ukloni duplicirane fotografije, videozapise i dokumente.

**Puni opis:**
Duplicate Cleaner pronalazi duplicirane datoteke na mobitelu i pomaže vam osloboditi prostor – sigurno i bez slanja ijedne fotografije na internet.

• Potpuno identične datoteke (SHA-256), čak i različitih naziva
• Iste fotografije različitih naziva i veličina (npr. WhatsApp kopije) – vizualna usporedba
• Slične fotografije za ručnu provjeru
• Datoteke istog naziva, ali različitog sadržaja – jasno označene, nikad se ne brišu automatski
• Pravila odabira datoteke koju zadržavate: starija/novija, veća/manja, veća rezolucija, prioritet mapa (npr. DCIM/Camera ima prednost, Download se briše prvi)
• Datum snimanja iz EXIF-a – stare fotografije prebačene na novi mobitel ostaju prepoznate kao starije
• Usporedni pregled s povećanjem prije brisanja, konačni popis i potvrda
• U svakoj grupi uvijek ostaje barem jedna datoteka
• Koš / oporavak izbrisanih datoteka
• Ograničenje veličine datoteka, odabir mapa, vremenski interval
• Skeniranje u pozadini
• Hrvatski i engleski jezik
• Bez oglasa, bez registracije, bez interneta

## English (en-US)
**Title:** Duplicate Cleaner

**Short description:** Find and safely remove duplicate photos, videos and documents.

**Full description:**
Duplicate Cleaner finds duplicate files on your phone and helps you free up space – safely, and without sending a single photo to the internet.

• Exact duplicates (SHA-256), even with different names
• The same photo with a different name or size (e.g. WhatsApp copies) – visual comparison
• Similar photos for manual review
• Same name but different content – clearly marked, never deleted automatically
• Rules for the file to keep: older/newer, larger/smaller, higher resolution, folder priority (e.g. keep DCIM/Camera, delete from Download first)
• Date taken from EXIF – old photos moved to a new phone are still recognised as older
• Side-by-side review with zoom, final list and confirmation before deleting
• At least one file always stays in every group
• Trash / recovery of deleted files
• File size limit, folder selection, date interval
• Background scanning
• Croatian and English
• No ads, no account, no internet

**Kategorija:** Alati (Tools) · **Oznake:** besplatno, bez oglasa
